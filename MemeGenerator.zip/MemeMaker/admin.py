from django.contrib import admin
from MemeMaker.models import Photo
# Register your models here.
admin.site.register(Photo)
