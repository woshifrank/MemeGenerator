from django.apps import AppConfig


class ImagesearcherConfig(AppConfig):
    name = 'MemeMaker'
